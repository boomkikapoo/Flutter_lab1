import 'package:flutter/material.dart';

class ReelsPage extends StatefulWidget {
  @override
  _ReelsPageState createState() => _ReelsPageState();
}

class _ReelsPageState extends State<ReelsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Scroll Page in Flutter"),
        backgroundColor: Colors.redAccent,
      ),
      body: ListView(
        children: [
          Container(
              color: Color.fromARGB(255, 247, 70, 1),
              height: 700,
              child: Center(
                  child: Image.network(
                      'https://cdn.shopify.com/s/files/1/1238/9850/articles/girlthatsshane--post-for-product--2022-07-08-08-17-46--instagram_1.jpg?v=1657652260&width=1950'))),
          Container(
              color: Color.fromARGB(255, 224, 50, 6),
              height: 700,
              child: Center(
                  child: Image.network(
                      'https://cdn.shopify.com/s/files/1/1238/9850/files/mr_preestige--p-a-i-d-i-n-f-l-u-e-n-c-e-r-s--2022-07-12-01-08-36--instagram_480x480.jpg?v=1657652174'))),
          Container(
              color: Color.fromARGB(255, 235, 78, 6),
              height: 700,
              child: Center(
                  child: Image.network(
                      'https://cdn.shopify.com/s/files/1/1238/9850/files/iamdhayes___post_for_product_2022_06_18_09_46_53_480x480.jpg?v=1657652242'))),
          Container(
              color: Colors.blue,
              height: 700,
              child: Center(
                  child: Image.network(
                      'https://cdn.shopify.com/s/files/1/1238/9850/articles/girlthatsshane--post-for-product--2022-07-08-08-17-46--instagram_1.jpg?v=1657652260&width=1950'))),
          Container(
              color: const Color.fromARGB(255, 107, 255, 77),
              height: 700,
              child: Center(
                  child: Image.network(
                      'https://image-cdn.hypb.st/https%3A%2F%2Fhypebeast.com%2Fimage%2F2017%2F11%2Foff-white-nike-sneaker-hype-gone-too-far-14.jpg?q=90&w=1090&format=jpeg&cbr=1&fit=max'))),
          Container(
              color: Colors.blue,
              height: 700,
              child: Center(
                  child: Image.network(
                      'https://image-cdn.hypb.st/https%3A%2F%2Fhypebeast.com%2Fimage%2F2017%2F11%2Foff-white-nike-sneaker-hype-gone-too-far-14.jpg?q=90&w=1090&format=jpeg&cbr=1&fit=max')))
        ],
      ),
    );
  }
}
