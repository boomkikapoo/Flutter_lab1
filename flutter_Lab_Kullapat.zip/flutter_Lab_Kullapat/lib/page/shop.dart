import 'package:flutter/material.dart';

class ShopPage extends StatelessWidget {
  final List<Product> products = [
    Product(
      name: 'Air jordan1 Travis Scott',
      price: 20000,
    ),
    Product(
      name: 'Air jordan1 Travis Scott x Fragment',
      price: 50000,
    ),
    Product(
      name: 'Air jordan1 x Dior',
      price: 150000,
    ),
    Product(
      name: 'Air Force1 x Supreme',
      price: 9000,
    ),
    Product(
      name: 'Air jordan1 Lost and found',
      price: 70,
    ),
    Product(
      name: 'Big red boot',
      price: 12000,
    ),
    Product(
      name: 'Adidas samba',
      price: 5000,
    ),
    Product(
      name: 'stussy tee',
      price: 4000,
    ),
    Product(
      name: 'New balance 530',
      price: 4300,
    ),
    Product(
      name: 'Stussy buckethat',
      price: 2000,
    ),
    Product(
      name: 'Amiri Jeans',
      price: 23000,
    ),
    Product(
      name: 'Lv belt',
      price: 12000,
    ),
    Product(
      name: 'Gucci Slipper',
      price: 25000,
    ),
    Product(
      name: 'Air force1 kwondo',
      price: 10000,
    ),
    Product(
      name: 'Crocs Slipper',
      price: 2000,
    ),
    Product(
      name: 'ChormeHeart Tee',
      price: 25000,
    ),

    // Add more products here
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shop Page'),
        backgroundColor: Colors.green,
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return ListTile(
            title: Text(product.name),
            subtitle: Text('\$${product.price.toStringAsFixed(2)}'),
            trailing: IconButton(
              icon: Icon(Icons.shopping_cart),
              onPressed: () {
                // Add the product to the shopping cart
              },
            ),
          );
        },
      ),
    );
  }
}

class Product {
  final String name;
  final double price;

  Product({
    required this.name,
    required this.price,
  });
}
