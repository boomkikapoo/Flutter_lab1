import 'package:flutter/material.dart';

class MyConstant {

  static Color primary = Color.fromARGB(0, 5, 9, 248);
  static Color success = Color.fromARGB(0, 5, 9, 248);
  static Color warning = Color.fromARGB(0, 5, 9, 248);
  static Color danger = Color.fromARGB(0, 5, 9, 248);
  static Color info = const Color.fromARGB(0, 5, 9, 248);
}